# Toon Studio Mobile — Android starter prototype

This is a starter project, not a finished Animate CC replacement.

## Included in this prototype
- Android-native app shell and preview canvas
- Import an image/character PNG from device storage
- Top-level layers and nested child layers in a simple layer list
- Timeline scrubber and basic keyframe marker bookkeeping
- Save project structure as JSON
- Export settings UI for resolution, FPS and bitrate (settings UI only; MP4 encoding is not implemented yet)
- GitHub Actions workflow to build a debug APK in the cloud

## Build APK without a laptop (phone-only workflow)
1. On your phone, open GitHub in Chrome and sign in/create an account.
2. Create a new repository named `ToonStudioMobile`.
3. Upload all files and folders from this project ZIP to the repository, preserving paths. If the mobile upload UI makes folder uploads difficult, use GitHub's browser desktop-site mode or GitHub's web editor to add files.
4. Open the repository's **Actions** tab, select **Build Android APK**, and tap **Run workflow**. A push to `main` also triggers the workflow.
5. When the run finishes successfully, open that workflow run, scroll to **Artifacts**, and download `ToonStudioMobile-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from that browser/file manager; only install APKs from your own trusted build.

## Local build requirements
- JDK 17
- Gradle 8.9
- Android SDK platform 35 and build tools

## Roadmap / important limitations
The project is a prototype foundation. It does NOT yet include true bone deformation, tween interpolation, nested symbol playback, multi-track audio, or actual MP4 export. Export settings currently demonstrate the intended UI only. These must be implemented and tested before this can be called a production animation app. A 2K/60 FPS output depends on device/encoder capability and project complexity.

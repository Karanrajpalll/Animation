package com.example.toonstudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Canvas
import android.graphics.RectF
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

private data class Layer(val id: Int, val name: String, val parentId: Int? = null, var visible: Boolean = true)

class MainActivity : Activity() {
    private val layers = mutableListOf(
        Layer(1, "Character", null), Layer(2, "Head", 1), Layer(3, "Body", 1),
        Layer(4, "Left Arm", 1), Layer(5, "Right Arm", 1), Layer(6, "Background", null)
    )
    private val keyframes = mutableMapOf<Int, MutableSet<Int>>()
    private var selectedFrame = 1
    private var frameCount = 120
    private var importedImage: Uri? = null
    private lateinit var layerBox: LinearLayout
    private lateinit var timelineLabel: TextView
    private lateinit var canvasView: PreviewView
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        renderLayers()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(20, 21, 32)); setPadding(12, 12, 12, 12) }
        val title = TextView(this).apply { text = "TOON STUDIO  •  MOBILE PROTOTYPE"; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER_VERTICAL; setPadding(4, 8, 4, 12) }
        root.addView(title)
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolbar.addView(btn("Import PNG") { choosePng() }, weight())
        toolbar.addView(btn("Add layer") { addLayer() }, weight())
        toolbar.addView(btn("Save project") { saveProject() }, weight())
        root.addView(toolbar)

        canvasView = PreviewView()
        root.addView(canvasView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f))

        val layerTitle = TextView(this).apply { text = "LAYERS  (tap a layer to select; nested layers are indented)"; setTextColor(Color.WHITE); textSize = 13f; setPadding(4, 10, 4, 5) }
        root.addView(layerTitle)
        val layerScroll = ScrollView(this)
        layerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        layerScroll.addView(layerBox)
        root.addView(layerScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 150))

        timelineLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding(4, 8, 4, 0); text = "TIMELINE  •  Frame 1 / $frameCount" }
        root.addView(timelineLabel)
        val seek = SeekBar(this).apply { max = frameCount - 1; progress = 0; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { selectedFrame = p + 1; updateTimelineLabel() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }) }
        root.addView(seek)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(btn("◆ Add keyframe") { keyframes.getOrPut(1) { mutableSetOf() }.add(selectedFrame); updateTimelineLabel() }, weight())
        bottom.addView(btn("Export settings") { showExportSettings() }, weight())
        root.addView(bottom)
        setContentView(root)
    }

    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 3, 3, 3) }
    private fun btn(text: String, action: () -> Unit) = Button(this).apply { this.text = text; textSize = 11f; setOnClickListener { action() } }

    private fun renderLayers() {
        layerBox.removeAllViews()
        layers.forEach { layer ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(if (layer.parentId == null) 6 else 30, 0, 4, 0) }
            val label = TextView(this).apply { text = (if (layer.parentId == null) "▾ " else "└  ") + layer.name; setTextColor(Color.WHITE); textSize = 14f; setPadding(8, 8, 8, 8) }
            row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn(if (layer.visible) "Visible" else "Hidden") { layer.visible = !layer.visible; renderLayers(); canvasView.invalidate() })
            row.addView(btn("＋ child") { layers.add(Layer((layers.maxOfOrNull { it.id } ?: 0) + 1, "Sub-layer", layer.id)); renderLayers() })
            row.setOnClickListener { Toast.makeText(this, "Selected: ${layer.name}", Toast.LENGTH_SHORT).show() }
            layerBox.addView(row)
        }
    }

    private fun addLayer() {
        layers.add(Layer((layers.maxOfOrNull { it.id } ?: 0) + 1, "New layer"))
        renderLayers()
    }

    private fun choosePng() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
        startActivityForResult(i, 41)
    }

    @Deprecated("Legacy callback kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK && data?.data != null) {
            importedImage = data.data
            try { contentResolver.openInputStream(importedImage!!)?.use { canvasView.bitmap = BitmapFactory.decodeStream(it) }; canvasView.invalidate() }
            catch (_: Exception) { Toast.makeText(this, "Image could not be opened", Toast.LENGTH_SHORT).show() }
        } else if (requestCode == 42 && resultCode == RESULT_OK && data?.data != null) {
            try { contentResolver.openOutputStream(data.data!!)?.use { it.write(pendingJson.toByteArray(Charsets.UTF_8)) }; Toast.makeText(this, "Project JSON saved", Toast.LENGTH_LONG).show() }
            catch (_: Exception) { Toast.makeText(this, "Could not save project", Toast.LENGTH_LONG).show() }
        }
    }

    private fun updateTimelineLabel() {
        val totalKeys = keyframes.values.sumOf { it.size }
        timelineLabel.text = "TIMELINE  •  Frame $selectedFrame / $frameCount  •  Keyframes: $totalKeys"
    }

    private fun saveProject() {
        val json = JSONObject()
        val arr = JSONArray()
        layers.forEach { l -> arr.put(JSONObject().put("id", l.id).put("name", l.name).put("parentId", l.parentId ?: JSONObject.NULL).put("visible", l.visible)) }
        json.put("format", "toon-studio-project-v1").put("fps", 30).put("frameCount", frameCount).put("layers", arr)
        val keys = JSONArray()
        keyframes.forEach { (id, frames) -> frames.forEach { f -> keys.put(JSONObject().put("layerId", id).put("frame", f)) } }
        json.put("keyframes", keys)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "toon-project.json") }
        pendingJson = json.toString(2)
        startActivityForResult(i, 42)
    }

    private fun showExportSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 8) }
        fun heading(t: String) = TextView(this).apply { text = t; setTextColor(Color.DKGRAY); textSize = 14f; setPadding(0, 8, 0, 4) }
        val resolution = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("1080p (1920×1080)", "2K (2560×1440)")) }
        val fps = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("24 FPS", "30 FPS", "60 FPS")) }
        val bitrate = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("8 Mbps", "16 Mbps", "25 Mbps", "40 Mbps", "60 Mbps")) }
        box.addView(heading("Resolution")); box.addView(resolution)
        box.addView(heading("Frame rate")); box.addView(fps)
        box.addView(heading("Video bitrate")); box.addView(bitrate)
        box.addView(TextView(this).apply { text = "Prototype note: these are planned export settings. MP4 rendering/encoding is not implemented in this starter build yet."; setTextColor(Color.DKGRAY); textSize = 12f; setPadding(0, 12, 0, 0) })
        AlertDialogCompat.show(this, box)
    }

    private var pendingJson: String = ""

    inner class PreviewView : View(this@MainActivity) {
        var bitmap: android.graphics.Bitmap? = null
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            c.drawColor(Color.rgb(31, 33, 49))
            p.color = Color.rgb(45, 48, 68)
            for (x in 0..width step 40) c.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), p)
            for (y in 0..height step 40) c.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), p)
            val b = bitmap
            if (b != null) {
                val scale = minOf(width.toFloat() / b.width, height.toFloat() / b.height, 1f)
                val w = b.width * scale; val h = b.height * scale
                c.drawBitmap(b, null, RectF((width-w)/2, (height-h)/2, (width+w)/2, (height+h)/2), p)
            } else {
                p.color = Color.WHITE; p.textSize = 20f
                c.drawText("Import a character PNG", 24f, height / 2f, p)
                p.textSize = 13f; p.color = Color.LTGRAY
                c.drawText("Canvas preview • Nested layer prototype", 24f, height / 2f + 28f, p)
            }
        }
    }

    override fun onResume() { super.onResume() }
}

private object AlertDialogCompat {
    fun show(activity: Activity, view: View) {
        android.app.AlertDialog.Builder(activity).setTitle("Export settings (prototype)").setView(view).setPositiveButton("Done", null).show()
    }
}
